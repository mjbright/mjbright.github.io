#!/bin/bash

# Check at least 1 master node has a GPU label:
GPU_MASTER_NODES=$(kubectl get nodes -l 'node-role.kubernetes.io/master,GPU' --no-headers -o custom-columns=NAME:.metadata.name)
#echo GPU_MASTER_NODES=$GPU_MASTER_NODES
[ -z "$GPU_MASTER_NODES" ] && { echo "No master nodes have a GPU label"; exit 1; }

# Check at least 0 worker nodes have a GPU label:
GPU_WORKER_NODES=$(kubectl get nodes -l '!node-role.kubernetes.io/master,GPU' --no-headers -o custom-columns=NAME:.metadata.name)
#echo GPU_WORKER_NODES=$GPU_WORKER_NODES
[ ! -z "$GPU_WORKER_NODES" ] && { echo "Some worker nodes have a GPU label"; exit 1; }

# Check pods are all running on one of the GPU nodes

for POD in $(kubectl get pods -o custom-columns=NAME:.metadata.name); do
    NODE=$(kubectl get pods -o custom-columns=NODE:.spec.nodeName --no-headers)
    for node in $GPU_WORKER_NODES; do
        [ "$node" = "$NODE" ] && {
            echo "Error: running on worker node"
            exit 1
        }
    done
done

exit 0


