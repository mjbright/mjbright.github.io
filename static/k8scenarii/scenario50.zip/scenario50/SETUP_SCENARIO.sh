
#export NS=k8scenario
#. ../TEMPLATE/functions.rc

[ -z "$1" ] && set -- --post-yaml

# Setup steps if any prior to applying yaml files:
if [ "$1" == "--pre-yaml" ];then
    exit 0
fi

# Setup steps if any after applying yaml files:
if [ "$1" == "--post-yaml" ];then
    # Just to warn if CONTEXT is not k8scenario: (if not set user commands must include '-n k8scenario')
    CHECK_CONTEXT

    NUM_MASTER=0
    for NODE in $(GET_WORKER_NODES); do
        # Label node as having a GPU
        kubectl label node $NODE --overwrite GPU-
    done

    for NODE in $(GET_MASTER_NODES); do
        let NUM_MASTER=NUM_MASTER+1

        # Untaint node if needed:
        kubectl describe node $NODE | grep ^Taint | grep -q node-role.kubernetes.io/master &&
            kubectl taint node kind-control-plane node-role.kubernetes.io/master-

        # Label node as having a GPU
        kubectl label node $NODE --overwrite GPU=NVidia

        # Requires nodeAffinity for more advanced matching:
        #case $NUM_MASTER in
        #    1) kubectl label node $NODE --overwrite GPU=present;;
        #    2) kubectl label node $NODE --overwrite GPU=NVidia;;
        #    3) kubectl label node $NODE --overwrite GPU=AMD;;
        #    4) kubectl label node $NODE --overwrite GPU=Mali;;
        #    *) kubectl label node $NODE --overwrite GPU=present;;
        #esac
    done

    exit 0
fi

exit 0

