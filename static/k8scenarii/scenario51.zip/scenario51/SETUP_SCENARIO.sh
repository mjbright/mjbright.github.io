
#export NS=k8scenario
#. ../TEMPLATE/functions.rc

[ -z "$1" ] && set -- --post-yaml

# Setup steps if any prior to applying yaml files:
if [ "$1" == "--pre-yaml" ];then
    exit 0
fi

# Setup steps if any after applying yaml files:
if [ "$1" == "--post-yaml" ];then
    # Just to warn if CONTEXT is not k8scenario: (if not set user commands must include '-n k8scenario')
    CHECK_CONTEXT

    # Taint all nodes as NoSchedule
    for NODE in $(GET_WORKER_NODES); do
	#echo "kubectl taint node $NODE --overwrite reason=testing:NoSchedule"
	kubectl taint node $NODE --overwrite reason=testing:NoSchedule
    done
    for NODE in $(GET_MASTER_NODES); do
	#echo "kubectl taint node $NODE --overwrite reason=testing:NoSchedule"
	kubectl taint node $NODE --overwrite reason=testing:NoSchedule
    done

    exit 0
fi

exit 0

