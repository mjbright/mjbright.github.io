
#set -x

kubectl describe nodes | grep -q ^Taint || exit 1
CHECK_PODS_PREFIXED "critical-" || exit 1

# Once check has succeeded in k8scenario we can undo any setup changes outside our namespace, e.g. removing temporary taints
[ ! -z "$K8SCENARIO_GO" ] && {

    echo "Fix succeeded, now removing 'reason' taints from all nodes"

    # Untaint all nodes as NoSchedule
    kubectl taint nodes reason- --all
    #for NODE in $(GET_WORKER_NODES); do kubectl taint node $NODE --overwrite reason-; done
    #for NODE in $(GET_MASTER_NODES); do kubectl taint node $NODE --overwrite reason-; done
}

# Should always get here ;-)
exit 0


