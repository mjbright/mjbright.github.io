
#set -x

# To test NodePort: (1st node)
echo; echo "---- Getting POD_ENDPOINT:"
POD_IP=$(GET_POD_IP_LABELLED "run=critical")
PORT=80
POD_ENDPOINT=${POD_IP}:${PORT}/1

echo; echo "---- Getting CLUSTERIP_ENDPOINT:"
CLUSTERIP_IP=$(GET_SVC_CLUSTERIP_IP "critical-svc")
PORT=80
CLUSTERIP_ENDPOINT=${CLUSTERIP_IP}:${PORT}/1

echo; echo "---- Getting NODE1_ENDPOINT:"
NODE_PORT=$(GET_SVC_NODEPORT_PORT "critical-svc")
NODE_IP=$(GET_NODE_IP 1)
NODE1_ENDPOINT=${NODE_IP}:${NODE_PORT}/1

echo; echo "---- Getting NODE2_ENDPOINT:"
NODE_IP=$(GET_NODE_IP 2)
NODE2_ENDPOINT=${NODE_IP}:${NODE_PORT}/1

echo; echo "---- Checking all endpoints:"
TEST_POD_SHELL "set -x; wget -qO - --timeout 1 $POD_ENDPOINT; RET=\$?; exit \$RET" || exit 1
TEST_POD_SHELL "set -x; wget -qO - --timeout 1 $CLUSTERIP_ENDPOINT; RET=\$?; exit \$RET" || exit 1
TEST_POD_SHELL "set -x; wget -qO - --timeout 1 $NODE1_ENDPOINT; RET=\$?; exit \$RET" || exit 1
TEST_POD_SHELL "set -x; wget -qO - --timeout 1 $NODE2_ENDPOINT; RET=\$?; exit \$RET" || exit 1

# Should always get here ;-)
exit 0
