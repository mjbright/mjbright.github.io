
Typo on label selector 'run: ckad-dem0' on service

