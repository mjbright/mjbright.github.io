
NS=scenario0

kubectl -n $NS get pods | grep ^basictest

