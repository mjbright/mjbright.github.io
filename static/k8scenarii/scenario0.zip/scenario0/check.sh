
kubectl -n k8scenario get pods | grep ^basictest

