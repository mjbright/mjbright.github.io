
An empty scenario0 will be created.

This a basic demo senario

Just need to create a pod with name starting 'basictest' e.g. basictest-xxxx
Creating a deployment is OK


