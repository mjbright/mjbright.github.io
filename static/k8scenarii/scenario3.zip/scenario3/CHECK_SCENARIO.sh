
set -x
# Check 'critical*' Pod is Running
# Check sleep has been changed to other than 'sleep 10'

GET_RUNNING_PODS_PREFIXED "critical" || exit 1

GET_RUNNING_PODS -o yaml | grep -qE "'sleep *10([^\d]|$)"

if [ $? -eq 0 ];then
    exit 1
else
    exit 0
fi


