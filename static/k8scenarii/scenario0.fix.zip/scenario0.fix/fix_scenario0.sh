kubectl run --generator=run-pod/v1 --image=mjbright/ckad-demo:1 basictest-xxx -n scenario0
