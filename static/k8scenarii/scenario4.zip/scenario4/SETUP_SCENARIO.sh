

[ -f ~/tmp/scenario$SCENARIO.txt ] && rm -f ~/tmp/scenario$SCENARIO.txt

exit 0

