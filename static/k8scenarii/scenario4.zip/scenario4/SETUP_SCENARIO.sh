

[ -f ~/tmp/scenario4.txt ] && rm -f ~/tmp/scenario4.txt

exit 0

