NOT TO BE DISCLOSED.

TODO: rename this as something other than README.txt !! (PRIVATE_INFO.txt ???)

This scenario ... ....

