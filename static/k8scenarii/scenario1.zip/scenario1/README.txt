# This scenario deploys a bad (non-existent) image

