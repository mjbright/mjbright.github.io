NS=scenario1

#kubectl -n scenario1 get pods | grep critical | grep Running && echo OK; echo $?
#set -x

kubectl -n $NS get pods | grep ^critical | grep Running && echo "Scenario OK"

