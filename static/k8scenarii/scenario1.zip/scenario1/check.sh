NS=scenario1

kubectl get pods/ckad-demo -n $NS |
	grep Running && echo "Scenario OK"

