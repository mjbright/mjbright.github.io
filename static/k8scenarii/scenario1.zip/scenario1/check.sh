kubectl get pods -n scenario1 | grep Running && echo "Scenario OK"
