kubectl -n scenario2 set selector service/ckad-demo run=ckad-demo
