kubectl -n scenario1 set image deploy/critical critical=mjbright/ckad-demo:1
