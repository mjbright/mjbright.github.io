This scenario deploys a bad (non-existent TAG) image
