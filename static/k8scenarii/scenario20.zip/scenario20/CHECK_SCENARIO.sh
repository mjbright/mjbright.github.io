#!/bin/sh

SVC_NAME=ckad-demo

# To test ClusterIP:
CHECK_SVC_CLUSTERIP $SVC_NAME /1 || exit 1
#CHECK_SVC_NODEPORT  $SVC_NAME /1 || exit 1



